<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('products','ProductsController@index');
Route::get('product/{id}', 'ProductsController@show');
Route::get('add-product', 'Products@controller@create');
Route::post('product', 'ProductsController@store');
Route::get('edit-product/{id}', 'ProductsController@edit');
Route::post('edit-product/{id}', 'ProductsController@update');
Route::post('destroy-products/{id}', 'ProductsController@destroy');
